package it.feio.android.omninotes.async.bus;

/**
 * Created by fede on 18/04/15.
 */
public class DynamicNavigationReadyEvent {

}
